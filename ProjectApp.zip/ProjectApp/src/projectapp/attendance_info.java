/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectapp;


public class attendance_info {
    
    
    private int index;
    private String name;
    private String username;
    private String password;
    private int d01;
    private int d02;
    private int d03;
    private int d04;
    private int d05;
    private int d06;
    private int d07;
    private int d08;
    private int d09;
    private int d10;
    private int d11;
    private int d12;
    private int d13;
    private int d14;
    private int d15;
    private int d16;
    private int d17;
    private int d18;
    private int d19;
    private int d20;
    private int d21;
    private int d22;
    private int d23;
    private int d24;
    private int d25;
    private int d26;
    private int d27;
    private int d28;
    private int d29;
    private int d30;
    private int d31;
    
    public attendance_info(int index, String name, String username, String password,int d01,int d02,int d03,int d04,int d05,int d06,int d07,int d08,int d09,int d10,int d11,int d12,int d13,int d14,int d15,int d16,int d17,int d18,int d19,int d20,int d21,int d22,int d23,int d24,int d25,int d26,int d27,int d28,int d29,int d30,int d31) 
    {
        this.index=index;
        this.name = name;
        this.username=username;
        this.password=password;
        this.d01=d01;
        this.d02=d02;
        this.d03=d03;
        this.d04=d04;
        this.d05=d05;
        this.d06=d06;
        this.d07=d07;
        this.d08=d08;
        this.d09=d09;
        this.d10=d10;
        this.d11=d11;
        this.d12=d12;
        this.d13=d13;
        this.d14=d14;
        this.d15=d15;
        this.d16=d16;
        this.d17=d17;
        this.d18=d18;
        this.d19=d19;
        this.d20=d20;
        this.d21=d21;
        this.d22=d22;
        this.d23=d23;
        this.d24=d24;
        this.d25=d25;
        this.d26=d26;
        this.d27=d27;
        this.d28=d28;
        this.d29=d29;
        this.d30=d30;
        this.d31=d31;
   
    }
    public int getIndex()
    {
        return index;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getUsername()
    {
        return username;
    }
    
    
    public String getPassword()
    {
        return password;
    }
    
    
    
    public int getd01()
    {
        return d01;
    }
    
    
    public int getd02()
    {
        return d02;
    }
    
    
    public int getd03()
    {
        return d03;
    }
    
    
    public int getd04()
    {
        return d04;
    }
    
    
    public int getd05()
    {
        return d05;
    }
    
    
    public int getd06()
    {
        return d06;
    }
    
    
    public int getd07()
    {
        return d07;
    }
    
    
    public int getd08()
    {
        return d08;
    }
    
    
    public int getd09()
    {
        return d09;
    }
    
    
    public int getd10()
    {
        return d10;
    }
    
    
    public int getd11()
    {
        return d11;
    }
    
    
    public int getd12()
    {
        return d12;
    }
    
    
    public int getd13()
    {
        return d13;
    }
    
    
    public int getd14()
    {
        return d14;
    }
    
    
    public int getd15()
    {
        return d15;
    }
    
    
    public int getd16()
    {
        return d16;
    }
    
    
    public int getd17()
    {
        return d17;
    }
    
    
    public int getd18()
    {
        return d18;
    }
    
    
    public int getd19()
    {
        return d19;
    }
    
    
    public int getd20()
    {
        return d20;
    }
    
    
    public int getd21()
    {
        return d21;
    }
    
    
    public int getd22()
    {
        return d22;
    }
    
    
    public int getd23()
    {
        return d23;
    }
    
    
    public int getd24()
    {
        return d24;
    }
    
    
    public int getd25()
    {
        return d25;
    }
    
    
    public int getd26()
    {
        return d26;
    }
    
    
    public int getd27()
    {
        return d27;
    }
    
    
    public int getd28()
    {
        return d28;
    }
    
    
    public int getd29()
    {
        return d29;
    }
    
    
    public int getd30()
    {
        return d30;
    }
    
    
    public int getd31()
    {
        return d31;
    }
    
}
